package com.cg.aps;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApartmentSecurityManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
